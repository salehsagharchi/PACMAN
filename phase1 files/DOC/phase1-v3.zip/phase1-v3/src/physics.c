#include "physics.h"

Direction decideGhost(const Map* map, Ghost* ghost) {
    // fill me
}

Direction decidePacman(const Map* map, Pacman* pacman, Action action) {
    // fill me
}
